// 全局状态
let currentPage = 'dashboard';
let currentModal = null;

// 页面路由配置
const pages = {
    dashboard: renderDashboard,
    schools: renderSchools,
    students: renderStudents,
    staff: renderStaff,
    'screening-plan': renderScreeningPlan,
    'screening-record': renderScreeningRecord,
    consent: renderConsent,
    results: renderResults,
    abnormal: renderAbnormal,
    feedback: renderFeedback,
    'consent-manage': renderConsentManage,
    parents: renderParents,
    statistics: renderStatistics,
    reports: renderReports,
};

// 初始化
function init() {
    DataStore.init();
    bindNavigation();
    navigateTo('dashboard');
}

// 绑定导航事件
function bindNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.page;
            navigateTo(page);
        });
    });
}

// 页面导航
function navigateTo(page) {
    currentPage = page;
    
    // 更新导航状态
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.page === page);
    });

    // 更新页面标题
    const titles = {
        dashboard: '数据看板',
        schools: '学校管理',
        students: '学生管理',
        staff: '医护团队',
        'screening-plan': '筛查计划',
        'screening-record': '筛查记录',
        consent: '知情同意',
        results: '筛查结果',
        abnormal: '异常台账',
        feedback: '反馈单管理',
        'consent-manage': '知情同意书管理',
        parents: '家长账号管理',
        statistics: '进展统计',
        reports: '数据导出',
    };
    document.getElementById('page-title').textContent = titles[page] || page;

    // 渲染页面内容
    const content = document.getElementById('page-content');
    if (pages[page]) {
        content.innerHTML = pages[page]();
        bindPageEvents(page);
    }
}

// 绑定页面内事件
function bindPageEvents(page) {
    // 搜索功能
    const searchInputs = document.querySelectorAll('.search-input');
    searchInputs.forEach(input => {
        input.addEventListener('input', debounce(() => {
            refreshCurrentPage();
        }, 300));
    });
}

// 防抖函数
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 刷新当前页面
function refreshCurrentPage() {
    if (pages[currentPage]) {
        document.getElementById('page-content').innerHTML = pages[currentPage]();
        bindPageEvents(currentPage);
    }
}

// ==================== 模态框 ====================

function openModal(title, content, onConfirm) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal">
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="btn btn-outline btn-sm" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" onclick="closeModal()">取消</button>
                <button class="btn btn-primary" id="modal-confirm">确定</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    currentModal = modal;
    
    if (onConfirm) {
        document.getElementById('modal-confirm').addEventListener('click', () => {
            onConfirm();
            closeModal();
        });
    }
}

function closeModal() {
    if (currentModal) {
        currentModal.remove();
        currentModal = null;
    }
}

// ==================== 页面渲染函数 ====================

// 数据看板
function renderDashboard() {
    const overview = Statistics.getOverview();
    const byItem = Statistics.getByItem();
    const recentAbnormal = DataStore.get('abnormalRecords').slice(0, 5);
    
    return `<div class="page-section">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon blue"><i class="fas fa-school"></i></div>
                <div class="stat-info"><h3>${overview.totalSchools}</h3><p>覆盖学校</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon green"><i class="fas fa-user-graduate"></i></div>
                <div class="stat-info"><h3>${overview.totalStudents}</h3><p>学生总数</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon orange"><i class="fas fa-clipboard-check"></i></div>
                <div class="stat-info"><h3>${overview.screenedCount}</h3><p>已筛查 (${overview.screeningRate}%)</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon red"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-info"><h3>${overview.abnormalCount}</h3><p>异常 (${overview.abnormalRate}%)</p></div>
            </div>
        </div>

        <div class="charts-row">
            <div class="chart-card">
                <h3>五健筛查异常分布</h3>
                <div class="screening-result">
                    <div class="result-item vision">
                        <h4>视力健康</h4>
                        <div class="result-value" style="color:#1890ff">${byItem.vision.rate}%</div>
                        <span class="tag tag-danger">${byItem.vision.abnormal}人异常</span>
                    </div>
                    <div class="result-item nutrition">
                        <h4>营养体重</h4>
                        <div class="result-value" style="color:#52c41a">${byItem.nutrition.rate}%</div>
                        <span class="tag tag-warning">${byItem.nutrition.abnormal}人异常</span>
                    </div>
                    <div class="result-item spine">
                        <h4>脊柱体态</h4>
                        <div class="result-value" style="color:#faad14">${byItem.spine.rate}%</div>
                        <span class="tag tag-warning">${byItem.spine.abnormal}人异常</span>
                    </div>
                    <div class="result-item oral">
                        <h4>口腔健康</h4>
                        <div class="result-value" style="color:#f5222d">${byItem.oral.rate}%</div>
                        <span class="tag tag-danger">${byItem.oral.abnormal}人异常</span>
                    </div>
                    <div class="result-item mental">
                        <h4>心理状态</h4>
                        <div class="result-value" style="color:#722ed1">${byItem.mental.rate}%</div>
                        <span class="tag tag-info">${byItem.mental.abnormal}人异常</span>
                    </div>
                </div>
            </div>
            <div class="list-card">
                <h3>最新异常记录</h3>
                <table class="data-table">
                    <thead><tr><th>学生</th><th>项目</th><th>等级</th></tr></thead>
                    <tbody>
                        ${recentAbnormal.map(r => `
                            <tr><td>${r.studentName}</td><td>${r.item}</td><td><span class="tag ${getRiskLevelTag(r.level)}">${r.level}</span></td></tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    </div>`;
}

// 学校管理
function renderSchools() {
    const keyword = document.querySelector('.search-input')?.value || '';
    const schools = DataStore.search('schools', keyword, ['name', 'district', 'contact']);
    
    return `<div class="page-section">
        <div class="search-bar">
            <input type="text" class="search-input" placeholder="搜索学校名称..." value="${keyword}">
            <select id="filter-type">
                <option value="">全部类型</option>
                <option value="幼儿园">幼儿园</option>
                <option value="小学">小学</option>
                <option value="中学">中学</option>
            </select>
            <button class="btn btn-primary" onclick="openAddSchoolModal()">
                <i class="fas fa-plus"></i> 添加学校
            </button>
        </div>
        <table class="data-table">
            <thead>
                <tr><th>ID</th><th>学校名称</th><th>类型</th><th>所属区县</th><th>学生数</th><th>联系人</th><th>联系电话</th><th>操作</th></tr>
            </thead>
            <tbody>
                ${schools.map(s => `
                    <tr>
                        <td>${s.id}</td>
                        <td>${s.name}</td>
                        <td><span class="tag tag-primary">${s.type}</span></td>
                        <td>${s.district}</td>
                        <td>${s.students}</td>
                        <td>${s.contact}</td>
                        <td>${s.phone}</td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick="editSchool(${s.id})">编辑</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteSchool(${s.id})">删除</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    </div>`;
}

function openAddSchoolModal() {
    const content = `
        <div class="form-row">
            <div class="form-group">
                <label>学校名称</label>
                <input type="text" id="school-name" placeholder="请输入学校名称">
            </div>
            <div class="form-group">
                <label>学校类型</label>
                <select id="school-type">
                    <option value="幼儿园">幼儿园</option>
                    <option value="小学">小学</option>
                    <option value="中学">中学</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>地址</label>
            <input type="text" id="school-address" placeholder="请输入地址">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>联系人</label>
                <input type="text" id="school-contact" placeholder="请输入联系人">
            </div>
            <div class="form-group">
                <label>联系电话</label>
                <input type="text" id="school-phone" placeholder="请输入联系电话">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>所属区县</label>
                <input type="text" id="school-district" placeholder="请输入区县">
            </div>
            <div class="form-group">
                <label>学生数</label>
                <input type="number" id="school-students" placeholder="请输入学生数">
            </div>
        </div>
    `;
    
    openModal('添加学校', content, () => {
        const school = {
            name: document.getElementById('school-name').value,
            type: document.getElementById('school-type').value,
            address: document.getElementById('school-address').value,
            contact: document.getElementById('school-contact').value,
            phone: document.getElementById('school-phone').value,
            district: document.getElementById('school-district').value,
            students: parseInt(document.getElementById('school-students').value) || 0
        };
        
        if (!school.name) {
            alert('学校名称不能为空！');
            return;
        }
        
        DataStore.add('schools', school);
        refreshCurrentPage();
    });
}

function editSchool(id) {
    const school = DataStore.get('schools').find(s => s.id === id);
    if (!school) return;
    
    const content = `
        <input type="hidden" id="edit-school-id" value="${school.id}">
        <div class="form-row">
            <div class="form-group">
                <label>学校名称</label>
                <input type="text" id="school-name" value="${school.name}">
            </div>
            <div class="form-group">
                <label>学校类型</label>
                <select id="school-type">
                    <option value="幼儿园" ${school.type === '幼儿园' ? 'selected' : ''}>幼儿园</option>
                    <option value="小学" ${school.type === '小学' ? 'selected' : ''}>小学</option>
                    <option value="中学" ${school.type === '中学' ? 'selected' : ''}>中学</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>地址</label>
            <input type="text" id="school-address" value="${school.address || ''}">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>联系人</label>
                <input type="text" id="school-contact" value="${school.contact || ''}">
            </div>
            <div class="form-group">
                <label>联系电话</label>
                <input type="text" id="school-phone" value="${school.phone || ''}">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>所属区县</label>
                <input type="text" id="school-district" value="${school.district || ''}">
            </div>
            <div class="form-group">
                <label>学生数</label>
                <input type="number" id="school-students" value="${school.students || 0}">
            </div>
        </div>
    `;
    
    openModal('编辑学校', content, () => {
        const updates = {
            name: document.getElementById('school-name').value,
            type: document.getElementById('school-type').value,
            address: document.getElementById('school-address').value,
            contact: document.getElementById('school-contact').value,
            phone: document.getElementById('school-phone').value,
            district: document.getElementById('school-district').value,
            students: parseInt(document.getElementById('school-students').value) || 0
        };
        
        DataStore.update('schools', id, updates);
        refreshCurrentPage();
    });
}

function deleteSchool(id) {
    if (confirm('确定要删除这所学校吗？')) {
        DataStore.delete('schools', id);
        refreshCurrentPage();
    }
}

// 学生管理
function renderStudents() {
    const keyword = document.querySelector('.search-input')?.value || '';
    const students = DataStore.search('students', keyword, ['name', 'guardian', 'phone', 'className']);
    
    return `<div class="page-section">
        <div class="search-bar">
            <input type="text" class="search-input" placeholder="搜索学生姓名..." value="${keyword}">
            <select id="filter-school">
                <option value="">全部学校</option>
                ${DataStore.get('schools').map(s => `<option value="${s.id}">${s.name}</option>`).join('')}
            </select>
            <select id="filter-status">
                <option value="">全部状态</option>
                <option value="待筛查">待筛查</option>
                <option value="已筛查">已筛查</option>
                <option value="异常">异常</option>
            </select>
            <button class="btn btn-primary" onclick="openAddStudentModal()">
                <i class="fas fa-plus"></i> 添加学生
            </button>
        </div>
        <table class="data-table">
            <thead>
                <tr><th>ID</th><th>姓名</th><th>性别</th><th>出生日期</th><th>学校</th><th>班级</th><th>家长</th><th>状态</th><th>操作</th></tr>
            </thead>
            <tbody>
                ${students.map(s => {
                    const school = getSchoolById(s.schoolId);
                    return `<tr>
                        <td>${s.id}</td>
                        <td>${s.name}</td>
                        <td>${s.gender}</td>
                        <td>${s.birthday}</td>
                        <td>${school ? school.name : ''}</td>
                        <td>${s.className}</td>
                        <td>${s.guardian}<br><small>${s.phone}</small></td>
                        <td><span class="tag ${getStatusTag(s.status)}">${s.status}</span></td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick="editStudent(${s.id})">编辑</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteStudent(${s.id})">删除</button>
                        </td>
                    </tr>`;
                }).join('')}
            </tbody>
        </table>
    </div>`;
}

function openAddStudentModal() {
    const schools = DataStore.get('schools');
    const content = `
        <div class="form-row">
            <div class="form-group">
                <label>姓名</label>
                <input type="text" id="student-name" placeholder="请输入姓名">
            </div>
            <div class="form-group">
                <label>性别</label>
                <select id="student-gender">
                    <option value="男">男</option>
                    <option value="女">女</option>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>出生日期</label>
                <input type="date" id="student-birthday">
            </div>
            <div class="form-group">
                <label>学校</label>
                <select id="student-school">
                    ${schools.map(s => `<option value="${s.id}">${s.name}</option>`).join('')}
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>班级</label>
                <input type="text" id="student-class" placeholder="如：三年级2班">
            </div>
            <div class="form-group">
                <label>家长姓名</label>
                <input type="text" id="student-guardian" placeholder="请输入家长姓名">
            </div>
        </div>
        <div class="form-group">
            <label>家长电话</label>
            <input type="text" id="student-phone" placeholder="请输入家长电话">
        </div>
    `;
    
    openModal('添加学生', content, () => {
        const student = {
            name: document.getElementById('student-name').value,
            gender: document.getElementById('student-gender').value,
            birthday: document.getElementById('student-birthday').value,
            schoolId: parseInt(document.getElementById('student-school').value),
            className: document.getElementById('student-class').value,
            guardian: document.getElementById('student-guardian').value,
            phone: document.getElementById('student-phone').value,
            status: '待筛查'
        };
        
        if (!student.name) {
            alert('学生姓名不能为空！');
            return;
        }
        
        DataStore.add('students', student);
        refreshCurrentPage();
    });
}

function editStudent(id) {
    const student = DataStore.get('students').find(s => s.id === id);
    if (!student) return;
    
    const schools = DataStore.get('schools');
    const content = `
        <div class="form-row">
            <div class="form-group">
                <label>姓名</label>
                <input type="text" id="student-name" value="${student.name}">
            </div>
            <div class="form-group">
                <label>性别</label>
                <select id="student-gender">
                    <option value="男" ${student.gender === '男' ? 'selected' : ''}>男</option>
                    <option value="女" ${student.gender === '女' ? 'selected' : ''}>女</option>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>出生日期</label>
                <input type="date" id="student-birthday" value="${student.birthday}">
            </div>
            <div class="form-group">
                <label>学校</label>
                <select id="student-school">
                    ${schools.map(s => `<option value="${s.id}" ${s.id === student.schoolId ? 'selected' : ''}>${s.name}</option>`).join('')}
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>班级</label>
                <input type="text" id="student-class" value="${student.className}">
            </div>
            <div class="form-group">
                <label>家长姓名</label>
                <input type="text" id="student-guardian" value="${student.guardian}">
            </div>
        </div>
        <div class="form-group">
            <label>家长电话</label>
            <input type="text" id="student-phone" value="${student.phone}">
        </div>
    `;
    
    openModal('编辑学生', content, () => {
        const updates = {
            name: document.getElementById('student-name').value,
            gender: document.getElementById('student-gender').value,
            birthday: document.getElementById('student-birthday').value,
            schoolId: parseInt(document.getElementById('student-school').value),
            className: document.getElementById('student-class').value,
            guardian: document.getElementById('student-guardian').value,
            phone: document.getElementById('student-phone').value
        };
        
        DataStore.update('students', id, updates);
        refreshCurrentPage();
    });
}

function deleteStudent(id) {
    if (confirm('确定要删除这名学生吗？')) {
        DataStore.delete('students', id);
        refreshCurrentPage();
    }
}

// 医护团队
function renderStaff() {
    const keyword = document.querySelector('.search-input')?.value || '';
    const staff = DataStore.search('staff', keyword, ['name', 'department', 'phone']);
    
    return `<div class="page-section">
        <div class="search-bar">
            <input type="text" class="search-input" placeholder="搜索姓名..." value="${keyword}">
            <select id="filter-dept">
                <option value="">全部科室</option>
                <option value="眼科">眼科</option>
                <option value="儿保科">儿保科</option>
                <option value="口腔科">口腔科</option>
                <option value="心理科">心理科</option>
            </select>
            <button class="btn btn-primary" onclick="openAddStaffModal()">
                <i class="fas fa-plus"></i> 添加医护
            </button>
        </div>
        <table class="data-table">
            <thead>
                <tr><th>ID</th><th>姓名</th><th>职称</th><th>科室</th><th>电话</th><th>状态</th><th>操作</th></tr>
            </thead>
            <tbody>
                ${staff.map(s => `
                    <tr>
                        <td>${s.id}</td>
                        <td>${s.name}</td>
                        <td>${s.title}</td>
                        <td><span class="tag tag-primary">${s.department}</span></td>
                        <td>${s.phone}</td>
                        <td><span class="tag tag-success">${s.status}</span></td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick="editStaff(${s.id})">编辑</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteStaff(${s.id})">删除</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    </div>`;
}

function openAddStaffModal() {
    const content = `
        <div class="form-row">
            <div class="form-group">
                <label>姓名</label>
                <input type="text" id="staff-name" placeholder="请输入姓名">
            </div>
            <div class="form-group">
                <label>职称</label>
                <input type="text" id="staff-title" placeholder="如：副主任医师">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>科室</label>
                <select id="staff-dept">
                    <option value="眼科">眼科</option>
                    <option value="儿保科">儿保科</option>
                    <option value="口腔科">口腔科</option>
                    <option value="心理科">心理科</option>
                </select>
            </div>
            <div class="form-group">
                <label>电话</label>
                <input type="text" id="staff-phone" placeholder="请输入电话">
            </div>
        </div>
    `;
    
    openModal('添加医护', content, () => {
        const staff = {
            name: document.getElementById('staff-name').value,
            title: document.getElementById('staff-title').value,
            department: document.getElementById('staff-dept').value,
            phone: document.getElementById('staff-phone').value,
            status: '在职'
        };
        
        if (!staff.name) {
            alert('姓名不能为空！');
            return;
        }
        
        DataStore.add('staff', staff);
        refreshCurrentPage();
    });
}

function editStaff(id) {
    const staff = DataStore.get('staff').find(s => s.id === id);
    if (!staff) return;
    
    const content = `
        <div class="form-row">
            <div class="form-group">
                <label>姓名</label>
                <input type="text" id="staff-name" value="${staff.name}">
            </div>
            <div class="form-group">
                <label>职称</label>
                <input type="text" id="staff-title" value="${staff.title}">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>科室</label>
                <select id="staff-dept">
                    <option value="眼科" ${staff.department === '眼科' ? 'selected' : ''}>眼科</option>
                    <option value="儿保科" ${staff.department === '儿保科' ? 'selected' : ''}>儿保科</option>
                    <option value="口腔科" ${staff.department === '口腔科' ? 'selected' : ''}>口腔科</option>
                    <option value="心理科" ${staff.department === '心理科' ? 'selected' : ''}>心理科</option>
                </select>
            </div>
            <div class="form-group">
                <label>电话</label>
                <input type="text" id="staff-phone" value="${staff.phone}">
            </div>
        </div>
    `;
    
    openModal('编辑医护', content, () => {
        const updates = {
            name: document.getElementById('staff-name').value,
            title: document.getElementById('staff-title').value,
            department: document.getElementById('staff-dept').value,
            phone: document.getElementById('staff-phone').value
        };
        
        DataStore.update('staff', id, updates);
        refreshCurrentPage();
    });
}

function deleteStaff(id) {
    if (confirm('确定要删除这名医护人员吗？')) {
        DataStore.delete('staff', id);
        refreshCurrentPage();
    }
}

// 筛查记录
function renderScreeningRecord() {
    const keyword = document.querySelector('.search-input')?.value || '';
    const records = DataStore.search('screeningRecords', keyword, ['studentName', 'school', 'screener']);
    
    return `<div class="page-section">
        <div class="search-bar">
            <input type="text" class="search-input" placeholder="搜索学生姓名..." value="${keyword}">
            <input type="date" id="filter-date">
            <select id="filter-result">
                <option value="">全部状态</option>
                <option value="正常">正常</option>
                <option value="异常">异常</option>
            </select>
            <button class="btn btn-primary" onclick="openAddScreeningModal()">
                <i class="fas fa-plus"></i> 录入筛查
            </button>
        </div>
        <table class="data-table">
            <thead>
                <tr><th>ID</th><th>学生</th><th>学校</th><th>班级</th><th>日期</th><th>筛查人</th><th>视力</th><th>营养</th><th>脊柱</th><th>口腔</th><th>心理</th><th>状态</th><th>操作</th></tr>
            </thead>
            <tbody>
                ${records.map(r => `
                    <tr>
                        <td>${r.id}</td>
                        <td>${r.studentName}</td>
                        <td>${r.school}</td>
                        <td>${r.className}</td>
                        <td>${r.date}</td>
                        <td>${r.screener}</td>
                        <td><span class="tag ${r.vision === '正常' ? 'tag-success' : 'tag-warning'}">${r.vision}</span></td>
                        <td><span class="tag ${r.nutrition === '正常' ? 'tag-success' : 'tag-warning'}">${r.nutrition}</span></td>
                        <td><span class="tag ${r.spine === '正常' ? 'tag-success' : 'tag-warning'}">${r.spine}</span></td>
                        <td><span class="tag ${r.oral === '正常' ? 'tag-success' : 'tag-warning'}">${r.oral}</span></td>
                        <td><span class="tag ${r.mental === '正常' ? 'tag-success' : 'tag-warning'}">${r.mental}</span></td>
                        <td><span class="tag ${getStatusTag(r.status)}">${r.status}</span></td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick="viewScreening(${r.id})">详情</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteScreening(${r.id})">删除</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    </div>`;
}

function openAddScreeningModal() {
    const students = DataStore.get('students').filter(s => s.status === '待筛查');
    const staff = DataStore.get('staff');
    
    if (students.length === 0) {
        alert('没有待筛查的学生！');
        return;
    }
    
    const content = `
        <div class="form-row">
            <div class="form-group">
                <label>学生</label>
                <select id="screening-student">
                    ${students.map(s => `<option value="${s.id}">${s.name} - ${s.className}</option>`).join('')}
                </select>
            </div>
            <div class="form-group">
                <label>筛查日期</label>
                <input type="date" id="screening-date" value="${new Date().toISOString().split('T')[0]}">
            </div>
        </div>
        <div class="form-group">
            <label>筛查人</label>
            <select id="screening-screener">
                ${staff.map(s => `<option value="${s.name}">${s.name} - ${s.department}</option>`).join('')}
            </select>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>视力</label>
                <select id="screening-vision">
                    <option value="正常">正常</option>
                    <option value="轻度异常">轻度异常</option>
                    <option value="需进一步检查">需进一步检查</option>
                </select>
            </div>
            <div class="form-group">
                <label>营养体重</label>
                <select id="screening-nutrition">
                    <option value="正常">正常</option>
                    <option value="偏瘦">偏瘦</option>
                    <option value="超重">超重</option>
                    <option value="肥胖">肥胖</option>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>脊柱体态</label>
                <select id="screening-spine">
                    <option value="正常">正常</option>
                    <option value="姿态不良">姿态不良</option>
                    <option value="脊柱侧弯风险">脊柱侧弯风险</option>
                </select>
            </div>
            <div class="form-group">
                <label>口腔健康</label>
                <select id="screening-oral">
                    <option value="正常">正常</option>
                    <option value="龋齿">龋齿</option>
                    <option value="牙周问题">牙周问题</option>
                    <option value="咬合异常">咬合异常</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>心理状态</label>
            <select id="screening-mental">
                <option value="正常">正常</option>
                <option value="情绪波动">情绪波动</option>
                <option value="需重点关注">需重点关注</option>
            </select>
        </div>
    `;
    
    openModal('录入筛查', content, () => {
        const studentId = parseInt(document.getElementById('screening-student').value);
        const student = getStudentById(studentId);
        const school = getSchoolById(student.schoolId);
        
        const vision = document.getElementById('screening-vision').value;
        const nutrition = document.getElementById('screening-nutrition').value;
        const spine = document.getElementById('screening-spine').value;
        const oral = document.getElementById('screening-oral').value;
        const mental = document.getElementById('screening-mental').value;
        
        const isAbnormal = vision !== '正常' || nutrition !== '正常' || spine !== '正常' || oral !== '正常' || mental !== '正常';
        
        const record = {
            studentId: studentId,
            studentName: student.name,
            school: school ? school.name : '',
            className: student.className,
            date: document.getElementById('screening-date').value,
            screener: document.getElementById('screening-screener').value,
            status: isAbnormal ? '异常' : '正常',
            vision: vision,
            nutrition: nutrition,
            spine: spine,
            oral: oral,
            mental: mental
        };
        
        DataStore.add('screeningRecords', record);
        
        // 更新学生状态
        DataStore.update('students', studentId, { status: isAbnormal ? '异常' : '已筛查' });
        
        // 如果有异常，添加到异常台账
        if (isAbnormal) {
            const items = [
                { key: 'vision', name: '视力', type: vision },
                { key: 'nutrition', name: '营养体重', type: nutrition },
                { key: 'spine', name: '脊柱体态', type: spine },
                { key: 'oral', name: '口腔健康', type: oral },
                { key: 'mental', name: '心理状态', type: mental }
            ];
            
            items.forEach(item => {
                if (item.type !== '正常') {
                    DataStore.add('abnormalRecords', {
                        studentId: studentId,
                        studentName: student.name,
                        school: school ? school.name : '',
                        className: student.className,
                        item: item.name,
                        type: item.type,
                        level: '轻度',
                        guidance: '请尽快就医检查',
                        needReferral: false,
                        followupPerson: record.screener,
                        followupDate: new Date().toISOString().split('T')[0],
                        status: '干预中'
                    });
                }
            });
        }
        
        refreshCurrentPage();
    });
}

function viewScreening(id) {
    const record = DataStore.get('screeningRecords').find(r => r.id === id);
    if (!record) return;
    
    const content = `
        <div class="screening-result">
            <div class="result-item vision">
                <h4>视力健康</h4>
                <div class="result-value" style="color:#1890ff">${record.vision}</div>
            </div>
            <div class="result-item nutrition">
                <h4>营养体重</h4>
                <div class="result-value" style="color:#52c41a">${record.nutrition}</div>
            </div>
            <div class="result-item spine">
                <h4>脊柱体态</h4>
                <div class="result-value" style="color:#faad14">${record.spine}</div>
            </div>
            <div class="result-item oral">
                <h4>口腔健康</h4>
                <div class="result-value" style="color:#f5222d">${record.oral}</div>
            </div>
            <div class="result-item mental">
                <h4>心理状态</h4>
                <div class="result-value" style="color:#722ed1">${record.mental}</div>
            </div>
        </div>
        <div style="margin-top:20px;">
            <p><strong>学生：</strong>${record.studentName}</p>
            <p><strong>学校：</strong>${record.school} ${record.className}</p>
            <p><strong>筛查日期：</strong>${record.date}</p>
            <p><strong>筛查人：</strong>${record.screener}</p>
        </div>
    `;
    
    openModal('筛查详情', content, null);
    document.getElementById('modal-confirm').style.display = 'none';
}

function deleteScreening(id) {
    if (confirm('确定要删除这条筛查记录吗？')) {
        DataStore.delete('screeningRecords', id);
        refreshCurrentPage();
    }
}

// 异常台账
function renderAbnormal() {
    const keyword = document.querySelector('.search-input')?.value || '';
    const records = DataStore.search('abnormalRecords', keyword, ['studentName', 'school', 'item', 'type']);
    
    return `<div class="page-section">
        <div class="search-bar">
            <input type="text" class="search-input" placeholder="搜索学生姓名..." value="${keyword}">
            <select id="filter-item">
                <option value="">全部项目</option>
                <option value="视力">视力</option>
                <option value="营养体重">营养体重</option>
                <option value="脊柱体态">脊柱体态</option>
                <option value="口腔健康">口腔健康</option>
                <option value="心理状态">心理状态</option>
            </select>
            <select id="filter-level">
                <option value="">全部等级</option>
                <option value="轻度">轻度</option>
                <option value="中度">中度</option>
                <option value="重度">重度</option>
            </select>
            <button class="btn btn-outline" onclick="exportAbnormal()">
                <i class="fas fa-download"></i> 导出
            </button>
        </div>
        <table class="data-table">
            <thead>
                <tr><th>ID</th><th>学生</th><th>学校</th><th>项目</th><th>类型</th><th>等级</th><th>指导</th><th>随访人</th><th>状态</th><th>操作</th></tr>
            </thead>
            <tbody>
                ${records.map(r => `
                    <tr>
                        <td>${r.id}</td>
                        <td>${r.studentName}</td>
                        <td>${r.school}</td>
                        <td><span class="tag tag-primary">${r.item}</span></td>
                        <td>${r.type}</td>
                        <td><span class="tag ${getRiskLevelTag(r.level)}">${r.level}</span></td>
                        <td>${r.guidance.substring(0, 20)}...</td>
                        <td>${r.followupPerson}</td>
                        <td><span class="tag ${getStatusTag(r.status)}">${r.status}</span></td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick="editAbnormal(${r.id})">编辑</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteAbnormal(${r.id})">删除</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    </div>`;
}

function editAbnormal(id) {
    const record = DataStore.get('abnormalRecords').find(r => r.id === id);
    if (!record) return;
    
    const content = `
        <div class="form-row">
            <div class="form-group">
                <label>风险等级</label>
                <select id="abnormal-level">
                    <option value="轻度" ${record.level === '轻度' ? 'selected' : ''}>轻度</option>
                    <option value="中度" ${record.level === '中度' ? 'selected' : ''}>中度</option>
                    <option value="重度" ${record.level === '重度' ? 'selected' : ''}>重度</option>
                </select>
            </div>
            <div class="form-group">
                <label>状态</label>
                <select id="abnormal-status">
                    <option value="干预中" ${record.status === '干预中' ? 'selected' : ''}>干预中</option>
                    <option value="已康复" ${record.status === '已康复' ? 'selected' : ''}>已康复</option>
                    <option value="待转诊" ${record.status === '待转诊' ? 'selected' : ''}>待转诊</option>
                    <option value="持续跟踪" ${record.status === '持续跟踪' ? 'selected' : ''}>持续跟踪</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>现场指导</label>
            <textarea id="abnormal-guidance" rows="3">${record.guidance}</textarea>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>随访人</label>
                <input type="text" id="abnormal-followup" value="${record.followupPerson}">
            </div>
            <div class="form-group">
                <label>随访日期</label>
                <input type="date" id="abnormal-date" value="${record.followupDate}">
            </div>
        </div>
        <div class="form-group">
            <label>整改康复情况</label>
            <textarea id="abnormal-recovery" rows="2">${record.recoveryStatus || ''}</textarea>
        </div>
    `;
    
    openModal('编辑异常记录', content, () => {
        const updates = {
            level: document.getElementById('abnormal-level').value,
            status: document.getElementById('abnormal-status').value,
            guidance: document.getElementById('abnormal-guidance').value,
            followupPerson: document.getElementById('abnormal-followup').value,
            followupDate: document.getElementById('abnormal-date').value,
            recoveryStatus: document.getElementById('abnormal-recovery').value
        };
        
        DataStore.update('abnormalRecords', id, updates);
        refreshCurrentPage();
    });
}

function deleteAbnormal(id) {
    if (confirm('确定要删除这条异常记录吗？')) {
        DataStore.delete('abnormalRecords', id);
        refreshCurrentPage();
    }
}

function exportAbnormal() {
    const records = DataStore.get('abnormalRecords');
    let csv = 'ID,学生,学校,班级,项目,类型,等级,指导,随访人,随访日期,状态\n';
    records.forEach(r => {
        csv += `${r.id},${r.studentName},${r.school},${r.className},${r.item},${r.type},${r.level},${r.guidance},${r.followupPerson},${r.followupDate},${r.status}\n`;
    });
    
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = '异常台账_' + new Date().toISOString().split('T')[0] + '.csv';
    link.click();
}

// 进展统计
function renderStatistics() {
    const overview = Statistics.getOverview();
    const byItem = Statistics.getByItem();
    
    return `<div class="page-section">
        <div class="search-bar">
            <input type="month" value="2026-05">
            <select><option>全部区县</option><option>市中区</option><option>历下区</option></select>
            <button class="btn btn-primary"><i class="fas fa-search"></i> 查询</button>
            <button class="btn btn-outline" onclick="exportStatistics()">
                <i class="fas fa-download"></i> 导出报表
            </button>
        </div>
        
        <div class="stats-grid" style="grid-template-columns: repeat(3, 1fr);">
            <div class="stat-card">
                <div class="stat-icon blue"><i class="fas fa-school"></i></div>
                <div class="stat-info"><h3>${overview.totalSchools}</h3><p>入校学校数</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon green"><i class="fas fa-users"></i></div>
                <div class="stat-info"><h3>${overview.screenedCount}</h3><p>筛查总人数</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon orange"><i class="fas fa-chalkboard-teacher"></i></div>
                <div class="stat-info"><h3>86</h3><p>科普宣讲场次</p></div>
            </div>
        </div>

        <div class="chart-card" style="margin-top:20px;">
            <h3>各类异常人数统计</h3>
            <table class="data-table">
                <thead><tr><th>筛查项目</th><th>筛查人数</th><th>异常人数</th><th>异常率</th><th>占比</th></tr></thead>
                <tbody>
                    <tr>
                        <td><span class="tag tag-primary">视力健康</span></td>
                        <td>${byItem.vision.total}</td>
                        <td>${byItem.vision.abnormal}</td>
                        <td>${byItem.vision.rate}%</td>
                        <td><div class="progress-bar" style="width:200px;"><div class="progress-fill" style="width:${byItem.vision.rate}%"></div></div></td>
                    </tr>
                    <tr>
                        <td><span class="tag tag-success">营养体重</span></td>
                        <td>${byItem.nutrition.total}</td>
                        <td>${byItem.nutrition.abnormal}</td>
                        <td>${byItem.nutrition.rate}%</td>
                        <td><div class="progress-bar" style="width:200px;"><div class="progress-fill" style="width:${byItem.nutrition.rate}%;background:#52c41a"></div></div></td>
                    </tr>
                    <tr>
                        <td><span class="tag tag-warning">脊柱体态</span></td>
                        <td>${byItem.spine.total}</td>
                        <td>${byItem.spine.abnormal}</td>
                        <td>${byItem.spine.rate}%</td>
                        <td><div class="progress-bar" style="width:200px;"><div class="progress-fill" style="width:${byItem.spine.rate}%;background:#faad14"></div></div></td>
                    </tr>
                    <tr>
                        <td><span class="tag tag-danger">口腔健康</span></td>
                        <td>${byItem.oral.total}</td>
                        <td>${byItem.oral.abnormal}</td>
                        <td>${byItem.oral.rate}%</td>
                        <td><div class="progress-bar" style="width:200px;"><div class="progress-fill" style="width:${byItem.oral.rate}%;background:#f5222d"></div></div></td>
                    </tr>
                    <tr>
                        <td><span class="tag tag-info">心理状态</span></td>
                        <td>${byItem.mental.total}</td>
                        <td>${byItem.mental.abnormal}</td>
                        <td>${byItem.mental.rate}%</td>
                        <td><div class="progress-bar" style="width:200px;"><div class="progress-fill" style="width:${byItem.mental.rate}%;background:#722ed1"></div></div></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>`;
}

function exportStatistics() {
    const overview = Statistics.getOverview();
    const byItem = Statistics.getByItem();
    
    let csv = '五健专项行动工作进展统计表\n\n';
    csv += `统计日期,${new Date().toLocaleDateString('zh-CN')}\n`;
    csv += `覆盖学校数,${overview.totalSchools}\n`;
    csv += `学生总数,${overview.totalStudents}\n`;
    csv += `已筛查人数,${overview.screenedCount}\n`;
    csv += `筛查率,${overview.screeningRate}%\n`;
    csv += `异常人数,${overview.abnormalCount}\n`;
    csv += `异常率,${overview.abnormalRate}%\n\n`;
    csv += '筛查项目,筛查人数,异常人数,异常率\n';
    csv += `视力健康,${byItem.vision.total},${byItem.vision.abnormal},${byItem.vision.rate}%\n`;
    csv += `营养体重,${byItem.nutrition.total},${byItem.nutrition.abnormal},${byItem.nutrition.rate}%\n`;
    csv += `脊柱体态,${byItem.spine.total},${byItem.spine.abnormal},${byItem.spine.rate}%\n`;
    csv += `口腔健康,${byItem.oral.total},${byItem.oral.abnormal},${byItem.oral.rate}%\n`;
    csv += `心理状态,${byItem.mental.total},${byItem.mental.abnormal},${byItem.mental.rate}%\n`;
    
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = '五健专项行动工作进展统计表_' + new Date().toISOString().split('T')[0] + '.csv';
    link.click();
}

// 其他页面占位
function renderScreeningPlan() {
    return `<div class="page-section">
        <div class="search-bar">
            <input type="date" placeholder="开始日期">
            <input type="date" placeholder="结束日期">
            <select><option value="">全部学校</option>${DataStore.get('schools').map(s => `<option value="${s.id}">${s.name}</option>`).join('')}</select>
            <button class="btn btn-primary"><i class="fas fa-plus"></i> 新建计划</button>
        </div>
        <div style="background:#fff;padding:40px;text-align:center;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
            <i class="fas fa-calendar-plus" style="font-size:48px;color:#d9d9d9;margin-bottom:16px;"></i>
            <h3 style="color:#999;margin-bottom:8px;">筛查计划管理</h3>
            <p style="color:#bbb;">功能开发中... 支持排期、分配医护团队、跟踪进度</p>
        </div>
    </div>`;
}

function renderConsent() {
    const students = DataStore.get('students');
    return `<div class="page-section">
        <div class="search-bar">
            <input type="text" class="search-input" placeholder="搜索学生姓名...">
            <select><option value="">全部状态</option><option value="已签署">已签署</option><option value="待签署">待签署</option></select>
            <button class="btn btn-primary"><i class="fas fa-paper-plane"></i> 批量发送</button>
        </div>
        <table class="data-table">
            <thead><tr><th>学生</th><th>学校</th><th>家长</th><th>联系电话</th><th>签署状态</th><th>操作</th></tr></thead>
            <tbody>
                ${students.map(s => `
                    <tr>
                        <td>${s.name}</td>
                        <td>${getSchoolById(s.schoolId)?.name || ''}</td>
                        <td>${s.guardian}</td>
                        <td>${s.phone}</td>
                        <td><span class="tag tag-success">已签署</span></td>
                        <td>
                            <button class="btn btn-outline btn-sm">查看</button>
                            <button class="btn btn-outline btn-sm">重新发送</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    </div>`;
}

function renderResults() {
    return `<div class="page-section">
        <div class="search-bar">
            <input type="text" placeholder="搜索学生姓名...">
            <select><option value="">全部项目</option><option>视力</option><option>营养</option><option>脊柱</option><option>口腔</option><option>心理</option></select>
            <button class="btn btn-primary"><i class="fas fa-search"></i> 查询</button>
        </div>
        <div style="background:#fff;padding:40px;text-align:center;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
            <i class="fas fa-chart-bar" style="font-size:48px;color:#d9d9d9;margin-bottom:16px;"></i>
            <h3 style="color:#999;margin-bottom:8px;">筛查结果分析</h3>
            <p style="color:#bbb;">功能开发中... 支持统计分析、趋势图表、对比分析</p>
        </div>
    </div>`;
}

function renderFeedback() {
    return `<div class="page-section">
        <div class="search-bar">
            <input type="text" placeholder="搜索学生姓名...">
            <button class="btn btn-primary"><i class="fas fa-plus"></i> 生成反馈单</button>
        </div>
        <div style="background:#fff;padding:40px;text-align:center;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
            <i class="fas fa-file-medical" style="font-size:48px;color:#d9d9d9;margin-bottom:16px;"></i>
            <h3 style="color:#999;margin-bottom:8px;">反馈单管理</h3>
            <p style="color:#bbb;">功能开发中... 支持生成、预览、发送个人反馈单</p>
        </div>
    </div>`;
}

function renderReports() {
    return `<div class="page-section">
        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:20px;">
            <div class="chart-card">
                <h3><i class="fas fa-file-excel" style="color:#52c41a;margin-right:8px;"></i>Excel导出</h3>
                <div style="margin-top:16px;">
                    <div style="padding:12px;border:1px solid #f0f0f0;border-radius:6px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
                        <span>学校信息表</span><button class="btn btn-outline" onclick="exportTable('schools', '学校信息表')"><i class="fas fa-download"></i> 导出</button>
                    </div>
                    <div style="padding:12px;border:1px solid #f0f0f0;border-radius:6px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
                        <span>学生信息表</span><button class="btn btn-outline" onclick="exportTable('students', '学生信息表')"><i class="fas fa-download"></i> 导出</button>
                    </div>
                    <div style="padding:12px;border:1px solid #f0f0f0;border-radius:6px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
                        <span>筛查记录表</span><button class="btn btn-outline" onclick="exportTable('screeningRecords', '筛查记录表')"><i class="fas fa-download"></i> 导出</button>
                    </div>
                    <div style="padding:12px;border:1px solid #f0f0f0;border-radius:6px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
                        <span>异常台账表</span><button class="btn btn-outline" onclick="exportAbnormal()"><i class="fas fa-download"></i> 导出</button>
                    </div>
                </div>
            </div>
            <div class="chart-card">
                <h3><i class="fas fa-cog" style="color:#1890ff;margin-right:8px;"></i>系统工具</h3>
                <div style="margin-top:16px;">
                    <div style="padding:12px;border:1px solid #f0f0f0;border-radius:6px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
                        <span>重置所有数据</span><button class="btn btn-danger" onclick="resetAllData()"><i class="fas fa-trash"></i> 重置</button>
                    </div>
                    <div style="padding:12px;border:1px solid #f0f0f0;border-radius:6px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
                        <span>数据备份</span><button class="btn btn-outline" onclick="backupData()"><i class="fas fa-download"></i> 备份</button>
                    </div>
                </div>
            </div>
        </div>
    </div>`;
}

// 通用导出功能
function exportTable(tableName, fileName) {
    const data = DataStore.get(tableName);
    if (data.length === 0) {
        alert('没有数据可导出！');
        return;
    }
    
    const headers = Object.keys(data[0]);
    let csv = headers.join(',') + '\n';
    data.forEach(row => {
        csv += headers.map(h => {
            const val = row[h] || '';
            return String(val).includes(',') ? `"${val}"` : val;
        }).join(',') + '\n';
    });
    
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = fileName + '_' + new Date().toISOString().split('T')[0] + '.csv';
    link.click();
}

function resetAllData() {
    if (confirm('确定要重置所有数据吗？此操作不可恢复！')) {
        DataStore.reset();
        refreshCurrentPage();
        alert('数据已重置！');
    }
}

function backupData() {
    const db = localStorage.getItem('wujian_db');
    const blob = new Blob([db], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = '五健筛查系统备份_' + new Date().toISOString().split('T')[0] + '.json';
    link.click();
}

// ========== 知情同意书管理 ==========
function renderConsentManage() {
    const keyword = document.querySelector('.search-input')?.value || '';
    const consents = DataStore.search('consentForms', keyword, ['studentName', 'parentName', 'phone']);
    
    return `<div class="page-section">
        <div class="search-bar">
            <input type="text" class="search-input" placeholder="搜索学生或家长姓名..." value="${keyword}">
            <button class="btn btn-outline" onclick="exportConsent()">
                <i class="fas fa-download"></i> 导出全部
            </button>
        </div>
        <table class="data-table">
            <thead>
                <tr><th>ID</th><th>学生姓名</th><th>家长姓名</th><th>手机号</th><th>签署时间</th><th>签名</th><th>操作</th></tr>
            </thead>
            <tbody>
                ${consents.map(c => `
                    <tr>
                        <td>${c.id}</td>
                        <td>${c.studentName}</td>
                        <td>${c.parentName}</td>
                        <td>${c.phone}</td>
                        <td>${new Date(c.signedAt).toLocaleString('zh-CN')}</td>
                        <td><span class="tag tag-success"><i class="fas fa-check"></i> 已签名</span></td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick="viewConsent(${c.id})">查看</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    </div>`;
}

function viewConsent(id) {
    const consent = DataStore.get('consentForms').find(c => c.id === id);
    if (!consent) return;
    
    const student = getStudentById(consent.studentId);
    const school = student ? getSchoolById(student.schoolId) : null;
    
    const content = `
        <div style="text-align:center;margin-bottom:20px;">
            <h3 style="color:#1890ff;margin-bottom:8px;">儿童青少年五健筛查知情同意书</h3>
            <p style="color:#999;font-size:13px;">签署编号：${String(consent.id).padStart(6, '0')}</p>
        </div>
        <div style="background:#fafafa;padding:16px;border-radius:8px;margin-bottom:16px;">
            <h4 style="margin-bottom:12px;">学生信息</h4>
            <p><strong>姓名：</strong>${consent.studentName}</p>
            <p><strong>学校：</strong>${school ? school.name : ''} ${student ? student.className : ''}</p>
            <p><strong>家长：</strong>${consent.parentName}</p>
            <p><strong>联系电话：</strong>${consent.phone}</p>
        </div>
        <div style="background:#fafafa;padding:16px;border-radius:8px;margin-bottom:16px;">
            <h4 style="margin-bottom:12px;">签署信息</h4>
            <p><strong>签署时间：</strong>${new Date(consent.signedAt).toLocaleString('zh-CN')}</p>
            <p><strong>IP地址：</strong>${consent.ipAddress || '未知'}</p>
        </div>
        <div style="text-align:center;">
            <h4 style="margin-bottom:12px;">家长签名</h4>
            <div style="border:1px solid #e8e8e8;border-radius:8px;padding:16px;background:#fff;">
                <img src="${consent.signature}" style="max-width:100%;max-height:150px;" alt="签名">
            </div>
        </div>
    `;
    
    openModal('知情同意书详情', content, null);
    document.getElementById('modal-confirm').style.display = 'none';
}

function exportConsent() {
    const consents = DataStore.get('consentForms');
    if (consents.length === 0) {
        alert('没有数据可导出！');
        return;
    }
    
    let csv = 'ID,学生姓名,家长姓名,手机号,签署时间\n';
    consents.forEach(c => {
        csv += `${c.id},${c.studentName},${c.parentName},${c.phone},${new Date(c.signedAt).toLocaleString('zh-CN')}\n`;
    });
    
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = '知情同意书_' + new Date().toISOString().split('T')[0] + '.csv';
    link.click();
}

// ========== 家长账号管理 ==========
function renderParents() {
    const keyword = document.querySelector('.search-input')?.value || '';
    const parents = DataStore.search('parentUsers', keyword, ['name', 'phone']);
    
    return `<div class="page-section">
        <div class="search-bar">
            <input type="text" class="search-input" placeholder="搜索家长姓名或手机号..." value="${keyword}">
        </div>
        <table class="data-table">
            <thead>
                <tr><th>ID</th><th>家长姓名</th><th>手机号</th><th>注册时间</th><th>学生数</th><th>操作</th></tr>
            </thead>
            <tbody>
                ${parents.map(p => {
                    const studentCount = DataStore.get('students').filter(s => s.parentId === p.id).length;
                    return `
                        <tr>
                            <td>${p.id}</td>
                            <td>${p.name}</td>
                            <td>${p.phone}</td>
                            <td>${new Date(p.createdAt).toLocaleString('zh-CN')}</td>
                            <td>${studentCount}</td>
                            <td>
                                <button class="btn btn-outline btn-sm" onclick="viewParent(${p.id})">查看</button>
                            </td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        </table>
    </div>`;
}

function viewParent(id) {
    const parent = DataStore.get('parentUsers').find(p => p.id === id);
    if (!parent) return;
    
    const students = DataStore.get('students').filter(s => s.parentId === id);
    const consent = DataStore.get('consentForms').find(c => c.parentId === id);
    
    let studentsHtml = students.map(s => {
        const school = getSchoolById(s.schoolId);
        return `<p>• ${s.name} - ${school ? school.name : ''} ${s.className} (${s.status})</p>`;
    }).join('');
    
    const content = `
        <div style="background:#fafafa;padding:16px;border-radius:8px;margin-bottom:16px;">
            <h4 style="margin-bottom:12px;">家长信息</h4>
            <p><strong>姓名：</strong>${parent.name}</p>
            <p><strong>手机号：</strong>${parent.phone}</p>
            <p><strong>注册时间：</strong>${new Date(parent.createdAt).toLocaleString('zh-CN')}</p>
        </div>
        <div style="background:#fafafa;padding:16px;border-radius:8px;margin-bottom:16px;">
            <h4 style="margin-bottom:12px;">关联学生</h4>
            ${studentsHtml || '<p style="color:#999;">暂无学生</p>'}
        </div>
        ${consent ? `
        <div style="background:#fafafa;padding:16px;border-radius:8px;">
            <h4 style="margin-bottom:12px;">知情同意书</h4>
            <p><strong>签署时间：</strong>${new Date(consent.signedAt).toLocaleString('zh-CN')}</p>
            <div style="margin-top:12px;text-align:center;">
                <img src="${consent.signature}" style="max-width:100%;max-height:120px;border:1px solid #e8e8e8;border-radius:4px;" alt="签名">
            </div>
        </div>
        ` : ''}
    `;
    
    openModal('家长详情', content, null);
    document.getElementById('modal-confirm').style.display = 'none';
}

// 启动应用
document.addEventListener('DOMContentLoaded', init);
