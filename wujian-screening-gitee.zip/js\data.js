// 数据管理模块 - 使用 localStorage 持久化存储
const DataStore = {
    // 初始化默认数据
    init() {
        if (!localStorage.getItem('wujian_db_initialized')) {
            const defaultData = {
                schools: [
                    { id: 1, name: "市第一实验小学", type: "小学", address: "市中区解放路1号", contact: "张老师", phone: "13800138001", district: "市中区", students: 0 },
                    { id: 2, name: "市第二中学", type: "中学", address: "市中区人民路2号", contact: "李老师", phone: "13800138002", district: "市中区", students: 0 },
                    { id: 3, name: "市实验幼儿园", type: "幼儿园", address: "市中区建设路3号", contact: "王老师", phone: "13800138003", district: "市中区", students: 0 },
                    { id: 4, name: "区第三小学", type: "小学", address: "历下区文化路4号", contact: "赵老师", phone: "13800138004", district: "历下区", students: 0 },
                    { id: 5, name: "区第五中学", type: "中学", address: "历下区经十路5号", contact: "刘老师", phone: "13800138005", district: "历下区", students: 0 },
                ],
                students: [],
                screeningRecords: [],
                abnormalRecords: [],
                staff: [
                    { id: 1, name: "李医生", title: "副主任医师", department: "眼科", phone: "13700137001", status: "在职" },
                    { id: 2, name: "王医生", title: "主治医师", department: "儿保科", phone: "13700137002", status: "在职" },
                    { id: 3, name: "张医生", title: "主治医师", department: "口腔科", phone: "13700137003", status: "在职" },
                    { id: 4, name: "刘医生", title: "副主任医师", department: "心理科", phone: "13700137004", status: "在职" },
                ],
                parentUsers: [],
                consentForms: [],
                nextId: { schools: 6, students: 1, screeningRecords: 1, abnormalRecords: 1, staff: 5, parentUsers: 1, consentForms: 1 }
            };
            localStorage.setItem('wujian_db', JSON.stringify(defaultData));
            localStorage.setItem('wujian_db_initialized', 'true');
        }
    },

    // 获取数据
    get(key) {
        const db = JSON.parse(localStorage.getItem('wujian_db') || '{}');
        return db[key] || [];
    },

    // 保存数据
    set(key, data) {
        const db = JSON.parse(localStorage.getItem('wujian_db') || '{}');
        db[key] = data;
        localStorage.setItem('wujian_db', JSON.stringify(db));
    },

    // 获取下一个ID
    getNextId(table) {
        const db = JSON.parse(localStorage.getItem('wujian_db') || '{}');
        db.nextId = db.nextId || {};
        db.nextId[table] = (db.nextId[table] || 1) + 1;
        localStorage.setItem('wujian_db', JSON.stringify(db));
        return db.nextId[table] - 1;
    },

    // 添加记录
    add(table, record) {
        const data = this.get(table);
        record.id = this.getNextId(table);
        data.push(record);
        this.set(table, data);
        return record;
    },

    // 更新记录
    update(table, id, updates) {
        const data = this.get(table);
        const index = data.findIndex(item => item.id === id);
        if (index !== -1) {
            data[index] = { ...data[index], ...updates };
            this.set(table, data);
            return data[index];
        }
        return null;
    },

    // 删除记录
    delete(table, id) {
        const data = this.get(table);
        const filtered = data.filter(item => item.id !== id);
        this.set(table, filtered);
        return filtered.length < data.length;
    },

    // 搜索记录
    search(table, keyword, fields) {
        const data = this.get(table);
        if (!keyword) return data;
        return data.filter(item => {
            return fields.some(field => {
                const value = String(item[field] || '').toLowerCase();
                return value.includes(keyword.toLowerCase());
            });
        });
    },

    // 重置数据
    reset() {
        localStorage.removeItem('wujian_db');
        localStorage.removeItem('wujian_db_initialized');
        this.init();
    }
};

// 统计数据计算
const Statistics = {
    getOverview() {
        const schools = DataStore.get('schools');
        const students = DataStore.get('students');
        const records = DataStore.get('screeningRecords');
        const abnormal = DataStore.get('abnormalRecords');
        
        const screenedCount = records.length;
        const totalStudents = students.length;
        const abnormalCount = abnormal.length;
        
        return {
            totalSchools: schools.length,
            totalStudents: totalStudents,
            screenedCount: screenedCount,
            abnormalCount: abnormalCount,
            screeningRate: totalStudents > 0 ? ((screenedCount / totalStudents) * 100).toFixed(1) : 0,
            abnormalRate: screenedCount > 0 ? ((abnormalCount / screenedCount) * 100).toFixed(1) : 0,
        };
    },

    getByItem() {
        const records = DataStore.get('screeningRecords');
        const items = ['vision', 'nutrition', 'spine', 'oral', 'mental'];
        const result = {};
        
        items.forEach(item => {
            const total = records.length;
            const abnormal = records.filter(r => r[item] !== '正常').length;
            result[item] = {
                total: total,
                abnormal: abnormal,
                rate: total > 0 ? ((abnormal / total) * 100).toFixed(1) : 0
            };
        });
        
        return result;
    }
};

// 工具函数
function getSchoolById(id) {
    return DataStore.get('schools').find(s => s.id === id);
}

function getStudentById(id) {
    return DataStore.get('students').find(s => s.id === id);
}

function getParentByPhone(phone) {
    return DataStore.get('parentUsers').find(p => p.phone === phone);
}

function getConsentByStudent(studentId) {
    return DataStore.get('consentForms').find(c => c.studentId === studentId);
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('zh-CN');
}

function getRiskLevelTag(level) {
    const map = { '轻度': 'tag-warning', '中度': 'tag-danger', '重度': 'tag-danger', '正常': 'tag-success' };
    return map[level] || 'tag-info';
}

function getStatusTag(status) {
    const map = {
        '正常': 'tag-success', '异常': 'tag-danger', '待筛查': 'tag-info',
        '已筛查': 'tag-primary', '干预中': 'tag-warning', '已康复': 'tag-success',
        '待转诊': 'tag-danger', '持续跟踪': 'tag-warning'
    };
    return map[status] || 'tag-info';
}

// 初始化数据
DataStore.init();
