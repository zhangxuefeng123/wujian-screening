// 演示数据 - 预录入学生、筛查记录和异常记录

const DemoData = {
    init() {
        // 检查是否已初始化演示数据
        if (localStorage.getItem('wujian_demo_initialized')) {
            return;
        }

        const db = JSON.parse(localStorage.getItem('wujian_db') || '{}');
        
        // 1. 添加学生数据（使用与app.js一致的字段名）
        const students = [
            { id: 1, name: "张小明", gender: "男", birthday: "2015-03-15", schoolId: 1, className: "三年级1班", guardian: "张大明", phone: "13900139001", status: "异常" },
            { id: 2, name: "李小红", gender: "女", birthday: "2014-07-20", schoolId: 1, className: "四年级2班", guardian: "李大红", phone: "13900139002", status: "异常" },
            { id: 3, name: "王小强", gender: "男", birthday: "2016-01-10", schoolId: 3, className: "大班1班", guardian: "王大强", phone: "13900139003", status: "已筛查" },
            { id: 4, name: "刘小美", gender: "女", birthday: "2013-09-05", schoolId: 2, className: "初一3班", guardian: "刘大美", phone: "13900139004", status: "异常" },
            { id: 5, name: "赵小华", gender: "男", birthday: "2015-11-25", schoolId: 4, className: "三年级1班", guardian: "赵大华", phone: "13900139005", status: "异常" },
            { id: 6, name: "陈小丽", gender: "女", birthday: "2014-04-18", schoolId: 5, className: "初二2班", guardian: "陈大丽", phone: "13900139006", status: "异常" },
            { id: 7, name: "孙小军", gender: "男", birthday: "2015-06-30", schoolId: 1, className: "三年级2班", guardian: "孙大军", phone: "13900139007", status: "已筛查" },
            { id: 8, name: "周小芳", gender: "女", birthday: "2016-08-12", schoolId: 3, className: "大班2班", guardian: "周大芳", phone: "13900139008", status: "异常" },
        ];
        
        // 2. 添加筛查记录（使用与app.js一致的字段名）
        const screeningRecords = [
            { id: 1, studentId: 1, studentName: "张小明", school: "市第一实验小学", className: "三年级1班", date: "2026-05-15", screener: "李医生", vision: "轻度异常", nutrition: "正常", spine: "正常", oral: "轻度异常", mental: "正常", status: "异常" },
            { id: 2, studentId: 2, studentName: "李小红", school: "市第一实验小学", className: "四年级2班", date: "2026-05-15", screener: "王医生", vision: "正常", nutrition: "轻度异常", spine: "正常", oral: "正常", mental: "正常", status: "异常" },
            { id: 3, studentId: 3, studentName: "王小强", school: "市实验幼儿园", className: "大班1班", date: "2026-05-16", screener: "李医生", vision: "正常", nutrition: "正常", spine: "正常", oral: "正常", mental: "正常", status: "正常" },
            { id: 4, studentId: 4, studentName: "刘小美", school: "市第二中学", className: "初一3班", date: "2026-05-16", screener: "张医生", vision: "中度异常", nutrition: "正常", spine: "轻度异常", oral: "正常", mental: "轻度异常", status: "异常" },
            { id: 5, studentId: 5, studentName: "赵小华", school: "区第三小学", className: "三年级1班", date: "2026-05-17", screener: "王医生", vision: "正常", nutrition: "正常", spine: "正常", oral: "中度异常", mental: "正常", status: "异常" },
            { id: 6, studentId: 6, studentName: "陈小丽", school: "区第五中学", className: "初二2班", date: "2026-05-17", screener: "刘医生", vision: "轻度异常", nutrition: "轻度异常", spine: "正常", oral: "正常", mental: "中度异常", status: "异常" },
            { id: 7, studentId: 7, studentName: "孙小军", school: "市第一实验小学", className: "三年级2班", date: "2026-05-18", screener: "李医生", vision: "正常", nutrition: "正常", spine: "正常", oral: "正常", mental: "正常", status: "正常" },
            { id: 8, studentId: 8, studentName: "周小芳", school: "市实验幼儿园", className: "大班2班", date: "2026-05-18", screener: "张医生", vision: "正常", nutrition: "正常", spine: "轻度异常", oral: "轻度异常", mental: "正常", status: "异常" },
        ];
        
        // 3. 添加异常记录（使用与app.js一致的字段名）
        const abnormalRecords = [
            { id: 1, studentId: 1, studentName: "张小明", school: "市第一实验小学", className: "三年级1班", item: "视力", type: "轻度异常", level: "轻度", guidance: "建议定期复查，注意用眼卫生", followupPerson: "李医生", followupDate: "2026-05-15", status: "干预中" },
            { id: 2, studentId: 1, studentName: "张小明", school: "市第一实验小学", className: "三年级1班", item: "口腔健康", type: "轻度异常", level: "轻度", guidance: "建议到口腔科进一步检查治疗", followupPerson: "张医生", followupDate: "2026-05-15", status: "待转诊" },
            { id: 3, studentId: 2, studentName: "李小红", school: "市第一实验小学", className: "四年级2班", item: "营养体重", type: "轻度异常", level: "轻度", guidance: "建议加强营养，定期监测体重", followupPerson: "王医生", followupDate: "2026-05-15", status: "干预中" },
            { id: 4, studentId: 4, studentName: "刘小美", school: "市第二中学", className: "初一3班", item: "视力", type: "中度异常", level: "中度", guidance: "建议尽快到眼科就诊，配戴合适眼镜", followupPerson: "李医生", followupDate: "2026-05-16", status: "待转诊" },
            { id: 5, studentId: 4, studentName: "刘小美", school: "市第二中学", className: "初一3班", item: "脊柱体态", type: "轻度异常", level: "轻度", guidance: "建议定期复查，注意坐姿", followupPerson: "王医生", followupDate: "2026-05-16", status: "持续跟踪" },
            { id: 6, studentId: 4, studentName: "刘小美", school: "市第二中学", className: "初一3班", item: "心理状态", type: "轻度异常", level: "轻度", guidance: "建议与家长沟通，适当减轻学习压力", followupPerson: "刘医生", followupDate: "2026-05-16", status: "干预中" },
            { id: 7, studentId: 5, studentName: "赵小华", school: "区第三小学", className: "三年级1班", item: "口腔健康", type: "中度异常", level: "中度", guidance: "建议尽快到口腔科治疗", followupPerson: "张医生", followupDate: "2026-05-17", status: "待转诊" },
            { id: 8, studentId: 6, studentName: "陈小丽", school: "区第五中学", className: "初二2班", item: "视力", type: "轻度异常", level: "轻度", guidance: "建议定期复查视力", followupPerson: "李医生", followupDate: "2026-05-17", status: "持续跟踪" },
            { id: 9, studentId: 6, studentName: "陈小丽", school: "区第五中学", className: "初二2班", item: "营养体重", type: "轻度异常", level: "轻度", guidance: "建议控制饮食，增加运动", followupPerson: "王医生", followupDate: "2026-05-17", status: "干预中" },
            { id: 10, studentId: 6, studentName: "陈小丽", school: "区第五中学", className: "初二2班", item: "心理状态", type: "中度异常", level: "中度", guidance: "建议到心理科进行专业评估", followupPerson: "刘医生", followupDate: "2026-05-17", status: "待转诊" },
            { id: 11, studentId: 8, studentName: "周小芳", school: "市实验幼儿园", className: "大班2班", item: "脊柱体态", type: "轻度异常", level: "轻度", guidance: "建议进行姿势矫正训练", followupPerson: "王医生", followupDate: "2026-05-18", status: "干预中" },
            { id: 12, studentId: 8, studentName: "周小芳", school: "市实验幼儿园", className: "大班2班", item: "口腔健康", type: "轻度异常", level: "轻度", guidance: "建议注意口腔卫生，定期复查", followupPerson: "张医生", followupDate: "2026-05-18", status: "持续跟踪" },
        ];
        
        // 更新学校学生数
        const schools = db.schools || [];
        schools.forEach(school => {
            school.students = students.filter(s => s.schoolId === school.id).length;
        });
        
        // 合并数据
        db.students = [...(db.students || []), ...students];
        db.screeningRecords = [...(db.screeningRecords || []), ...screeningRecords];
        db.abnormalRecords = [...(db.abnormalRecords || []), ...abnormalRecords];
        db.schools = schools;
        
        // 更新 nextId
        db.nextId = db.nextId || {};
        db.nextId.students = 9;
        db.nextId.screeningRecords = 9;
        db.nextId.abnormalRecords = 13;
        
        localStorage.setItem('wujian_db', JSON.stringify(db));
        localStorage.setItem('wujian_demo_initialized', 'true');
        
        console.log('演示数据初始化完成！');
        console.log(`- 学生: ${students.length}人`);
        console.log(`- 筛查记录: ${screeningRecords.length}条`);
        console.log(`- 异常记录: ${abnormalRecords.length}条`);
    }
};

// 页面加载时自动初始化演示数据
document.addEventListener('DOMContentLoaded', () => {
    DemoData.init();
});
